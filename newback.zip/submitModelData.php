<?php
include("config.php");
if(isset($_POST['v_number'])){
   
    $v_name = $_POST['v_name'];
    $v_email = $_POST['v_email'];
    $v_number = $_POST['v_number'];
    $v_address = $_POST['v_address'];
    $sql = "INSERT INTO `vendor`(`user_reg_id`,`name`, `email`, `mobile_no`, `address`) VALUES ('$_SESSION[id]','$v_name','$v_email','$v_number','$v_address')";
    if($conn->exec($sql)){
       //sel all vendor list
       $sl_vendor_list = "SELECT * FROM `vendor` where user_reg_id='$_SESSION[id]'";
       $vendorList_Q = $conn->query($sl_vendor_list);
       $dataList = '<select id="vendorList" name="vendor_name" class="form-select" onChange="createVendor(this.value)" required><option value="">Select Vendor</option>';
       while($data = $vendorList_Q->fetch(PDO::FETCH_ASSOC)){
          $dataList .= '<option value="'.$data['id'].'">'.$data['name'].' - '.$data['mobile_no'].'</option>';
       }
      $dataList .= '<optgroup label="For a new vendor"></optgroup><option>Add New</option></select>'; 
      echo $dataList;
    }else{
        echo 0;
    }
}

if(isset($_POST['item_code'])){
  $item_code=$_POST['item_code'];
  $item_name=$_POST['item_name'];
  $item_description=$_POST['item_description'];
  $vender_name=$_POST['vendor_name1'];
  $category=$_POST['category1'];
  $measurement_unit=$_POST['measurement_unit'];
  $weight_unit=$_POST['weight_unit'];
  $location=$_POST['location1'];
  $sql="INSERT INTO `items`(user_reg_id,item_code, item_name, item_desc, vender_name, category, measurement_unit, weight_unit, location_name) VALUES ('$_SESSION[id]','$item_code','$item_name','$item_description','$vender_name','$category','$measurement_unit','$weight_unit','$location')";
  if($conn->exec($sql)){
       //sel all vendor list
       $sl_items_list = "SELECT * FROM `items` where user_reg_id='$_SESSION[id]'";
       $itemList_Q = $conn->query($sl_items_list);
       $dataList = '<select id="textarea1" name="all_item[]" class="form-select" onchange="createItem(this.value)" required><option value="">Select Item Name</option>';
       while($data = $itemList_Q->fetch(PDO::FETCH_ASSOC)){
          $dataList .= '<option value="'.$data['id'].'">'.$data['item_name'].'</option>';
       }
      $dataList .= '<optgroup label="For a new item"></optgroup><option>Add New</option></select>'; 
      echo $dataList;
    }else{
        echo 0;
    }
}

if(isset($_POST['c_name'])){
  $c_name = $_POST['c_name'];
    $c_description = $_POST['c_description'];
    $c_units = $_POST['c_units'];
    $percentageType = $_POST['percentageType'];
    $sql = "INSERT INTO `category` (user_reg_id, Category_Name, Description_No, Measuring_Units, percentage) VALUES('$_SESSION[id]', '$c_name', '$c_description', '$c_units', '$percentageType')";
  if($conn->exec($sql)){
       //sel all vendor list
       $sl_category_list = "SELECT * FROM `category` where user_reg_id='$_SESSION[id]'";
       $categoryList_Q = $conn->query($sl_category_list);
       $dataList = '<select id="category1" name="category1" class="form-select" required><option value="">Select Category</option>';
       while($data = $categoryList_Q->fetch(PDO::FETCH_ASSOC)){
          $dataList .= '<option value="'.$data['id'].'">'.$data['Category_Name'].'</option>';
       }
      echo $dataList;
    }else{
        echo 0;
    }
}

if(isset($_POST['category_name'])){
    $c_name = $_POST['category_name'];
    $c_description = $_POST['c_description'];
    $c_units = $_POST['c_units'];
    $c_weights = $_POST['weights'];
    $sql = "INSERT INTO `category` (user_reg_id,Category_Name, Description_No, Measuring_Units, percentage) VALUES('$_SESSION[id]','$c_name', '$c_description', '$c_units', '$percentageType')";
  if($conn->exec($sql)){
       //sel all vendor list
       $sl_category_list = "SELECT * FROM `category` where user_reg_id='$_SESSION[id]'";
       $categoryList_Q = $conn->query($sl_category_list);
       $dataList = '<select id="category" name="category" onchange="createItem(this.value)" class="form-select" required><option value="">Select Category</option>';
       while($data = $categoryList_Q->fetch(PDO::FETCH_ASSOC)){
          $dataList .= '<option value="'.$data['id'].'">'.$data['Category_Name'].'</option>';
       }
      $dataList .= '<optgroup label="For a new item"></optgroup><option>Add New</option></select>';        
      echo $dataList;
    }else{
        echo 0;
    }
}


?>