<?php
error_reporting(0);
session_start();
$dsn = "mysql:host=localhost;dbname=adminpan_new_dashboard;charset=UTF8";
$user="adminpan_new_dashboard_user";
$password="g*TGDBYZg8W*";
try {
	$conn = new PDO($dsn, $user, $password);

	if ($conn) {
		// echo '<script>alert("Connected");</script>';
	}
	
  //if(!isset($_SESSION['id']) && empty($_SESSION['id']))header("location:/");	
} catch (PDOException $e) {
	echo $e->getMessage();
} 
date_default_timezone_set('Asia/Calcutta');
$currentTime=strtotime(date('d-m-Y  H:i:s'));
?>