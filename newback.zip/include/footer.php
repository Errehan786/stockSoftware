<script src="https://use.fontawesome.com/32f073b29a.js"></script>
<footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            ©
                            <script>document.write(new Date().getFullYear())</script>
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-end d-none d-sm-block">
                                Design & Develop by RSS Infotech Pvt Ltd
                            </div>
                        </div>
                    </div>
                </div>
            </footer>