<?php
if(!isset($_SESSION['id']) && empty($_SESSION['id'])){
    
?>
<script language="javascript">
 window.location.href="logout.php";
</script>
<?php
}
else
{
?>
<?php
}
?>
